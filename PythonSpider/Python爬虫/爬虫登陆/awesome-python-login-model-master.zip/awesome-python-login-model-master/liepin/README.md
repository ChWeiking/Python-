# scrapy_liepin

scrapy爬猎聘,通过公司名搜索公司职位
